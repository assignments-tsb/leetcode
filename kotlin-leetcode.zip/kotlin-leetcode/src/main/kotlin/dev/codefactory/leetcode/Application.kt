package dev.codefactory.leetcode

import io.micronaut.runtime.Micronaut.run
fun main(args: Array<String>) {
	run(*args)
}

